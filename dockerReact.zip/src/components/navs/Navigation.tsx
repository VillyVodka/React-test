import React, {useState, memo, useMemo} from 'react';
import {Menu} from 'antd';
import type {MenuProps} from 'antd';
import {Col, Row} from 'antd';
import {useNavigate, useLocation} from "react-router-dom";
import routes from '../../nav/routes';

const Navigation = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [current, setCurrent] = useState<string>(location.pathname);
    const items: MenuProps['items'] = useMemo(() => Object.values(routes).map((item) => ({
        label: item.name,
        key: item.url,
    })), []);

    const onClick: MenuProps['onClick'] = (e) => {
        setCurrent(e.key);
        navigate(e.key);
    };

    return (
        <Row>
            <Col span={24}>
                <Menu onClick={onClick} selectedKeys={[current]} mode="horizontal" items={items}/>
            </Col>
        </Row>
    )
}

export default memo(Navigation)