import React, {FC, ReactNode, memo} from 'react';
import {Layout} from 'antd';
import Navigation from '../navs/Navigation';

interface IProps {
    children: ReactNode;
}

const {Content} = Layout;

const BaseLayout: FC<IProps> = ({children}) => {
    return (
        <Layout className="layout">
            <Navigation/>
            <Content className="main">
                {children}
            </Content>
        </Layout>
    )
}

export default memo(BaseLayout)