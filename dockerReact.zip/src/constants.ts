export const baseUrl = 'https://api.github.com/search/repositories?q=node+in:name+language:javascript&sort=stars&order=desc&per_page=3&page=1'
export const mainOptionsChart = {
    title: {
        text: 'My chart'
    },
    yAxis: {
        title: {
            text: 'Watchers'
        }
    },
    chart: {
        type: 'column'
    },
    series: [{
        data: []
    }],
}