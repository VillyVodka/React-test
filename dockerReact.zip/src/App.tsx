import {Route, Routes} from "react-router-dom"
import React from 'react';
import SecondPage from "./pages/SecondPage";
import Home from "./pages/Home";
import routes from "./nav/routes";
import ThirdPage from "./pages/ThirdPage";

function App() {
    return (
        <Routes>
            <Route path={routes.home.url} element={<Home/>}/>
            <Route path={routes.second.url} element={<SecondPage/>}/>
            <Route path={routes.third.url} element={<ThirdPage/>}/>
        </Routes>
    )
}

export default App;
