import React, {memo} from 'react';
import BaseLayout from '../components/layouts/BaseLayout';

const ThirdPage = () => {

    return (
        <BaseLayout>
            <p className="text-center">
                third page
            </p>
        </BaseLayout>
    )
}

export default memo(ThirdPage)