import React, {memo} from 'react';
import BaseLayout from '../components/layouts/BaseLayout';

const Home = () => {

    return (
        <BaseLayout>
            <p className="text-center">
                home page
            </p>
        </BaseLayout>
    )
}

export default memo(Home)