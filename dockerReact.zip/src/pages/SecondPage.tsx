import React, {useEffect, useState, memo} from 'react';
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import BaseLayout from "../components/layouts/BaseLayout";
import {baseUrl, mainOptionsChart} from '../constants';

interface IChartItem {
    watchers: number,
    name: string
}

const SecondPage = () => {
    const [options, setOptions] = useState<Record<string, any>>(mainOptionsChart);
    const [isErrorFetchData, setIsErrorFetchData] = useState<Boolean>(false)

    useEffect(() => {
        fetch(baseUrl)
            .then(res => res.json())
            .then(({items}) => {
                setOptions({
                    ...options,
                    series: items.map(({watchers, name}: IChartItem) => ({
                        name: name,
                        data: [watchers]
                    }))
                })
            })
            .catch(() => {
                setIsErrorFetchData(true)
            })

        // eslint-disable-next-line
    }, [])

    return (
        <BaseLayout>
            {
                isErrorFetchData ?
                    <p className="text-center">
                        Error fetch data
                    </p>
                    :
                    <HighchartsReact
                        highcharts={Highcharts}
                        options={options}
                    />
            }
        </BaseLayout>
    )
}

export default memo(SecondPage)