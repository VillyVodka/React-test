const routes = {
    home: {
        name: 'Home',
        url: '/'
    },
    second: {
        name: "Second page",
        url: '/second'
    },
    third: {
        name: "Third page",
        url: '/third'
    },
}

export default routes