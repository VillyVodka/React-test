after run command:
### `docker`

Open [http://localhost](http://localhost)